import { Component, Inject, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'accident-search',
  templateUrl: './search.component.html'
})
export class AccidentSearchComponent implements OnInit {

  private results: any[];

  private searchText: string;

  constructor(http: HttpClient, @Inject('BASE_URL') baseUrl: string,private route:ActivatedRoute, private router: Router) {
    this.results = [];
    this.searchText = "";
  }

  search() {
    this.router.navigate(['/accidents/search', this.searchText]);
  }

  ngOnInit() {

    this.route.paramMap.subscribe(params => {

      this.searchText = params.get('text');



    });
  }
}

