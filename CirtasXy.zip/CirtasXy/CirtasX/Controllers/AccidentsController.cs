﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CirtasX.DataModels;

namespace CirtasX.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccidentsController : ControllerBase
    {
        private readonly CirtasDataModel _context;

        public AccidentsController(CirtasDataModel context)
        {
            _context = context;
        }

        // GET: api/Accidents
        [Route("{text:string}")]
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Accident>>> GetAccidents(string text)
        {
            text = text.Trim();

            var qry = _context.Accidents.AsQueryable();

            if (text == null)
            {
                if(text.Contains("+"))
                { 
                    var words = text.Split('+');

                    foreach (var word in words)
                    {
                        if(word.Contains(":"))
                        {
                            var parts = word.Split(':');

                            if(parts.Length == 2)
                            {
                                var field = parts[0];
                                var value = parts[1];

                                switch (field)
                                {
                                    case "id":
                                        if (int.TryParse(value, out int valueAsInt))
                                        {
                                            qry = qry.Where(x => x.AccidentID == valueAsInt);
                                        }
                                        break;
                                }

                            }
                        }

                    }
                }

                return await _context.Accidents.ToListAsync();
            }
            else
            {

            }
   
        }

        // GET: api/Accidents/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Accident>> GetAccident(int id)
        {
            var accident = await _context.Accidents.FindAsync(id);

            if (accident == null)
            {
                return NotFound();
            }

            return accident;
        }

        // PUT: api/Accidents/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutAccident(int id, Accident accident)
        {
            if (id != accident.AccidentID)
            {
                return BadRequest();
            }

            _context.Entry(accident).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!AccidentExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Accidents
        [HttpPost]
        public async Task<ActionResult<Accident>> PostAccident(Accident accident)
        {
            _context.Accidents.Add(accident);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetAccident", new { id = accident.AccidentID }, accident);
        }

        // DELETE: api/Accidents/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Accident>> DeleteAccident(int id)
        {
            var accident = await _context.Accidents.FindAsync(id);
            if (accident == null)
            {
                return NotFound();
            }

            _context.Accidents.Remove(accident);
            await _context.SaveChangesAsync();

            return accident;
        }

        private bool AccidentExists(int id)
        {
            return _context.Accidents.Any(e => e.AccidentID == id);
        }
    }
}
