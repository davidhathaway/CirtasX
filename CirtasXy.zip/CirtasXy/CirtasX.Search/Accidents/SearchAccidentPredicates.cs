﻿using CirtasX.DataModels;
using System;
using System.Collections.Generic;
using System.Text;

namespace CirtasX.Search.Accidents
{
    public class SearchAccidentPredicates : ISearchAccidentPredicates
    {
        public ICollection<SearchFieldPredicate<Accident>> Predicates { get; set; }

        public SearchAccidentPredicates()
        {
            Predicates = new List<SearchFieldPredicate<Accident>>()
            {
                new SearchFieldPredicate<Accident>("id", (entity, value)=>entity.AccidentID == int.Parse(value))
            };
            
        }


    }
}
