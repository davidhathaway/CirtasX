﻿using CirtasX.DataModels;
using System.Collections.Generic;

namespace CirtasX.Search.Accidents
{
    public interface ISearchAccidentPredicates
    {
        ICollection<SearchFieldPredicate<Accident>> Predicates { get; set; }
    }
}