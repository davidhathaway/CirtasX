﻿using System;
using System.Linq.Expressions;

namespace CirtasX.Search
{
    public class SearchFieldPredicate<T>
    {
        public string FieldName { get; set; }

        public Expression<Func<T, string, bool>> Predicate { get; set; }

        public SearchFieldPredicate(string fieldName, Expression<Func<T, string, bool>> predicate)
        {
            FieldName = fieldName;
            Predicate = predicate;
        } 
    }

   
}
