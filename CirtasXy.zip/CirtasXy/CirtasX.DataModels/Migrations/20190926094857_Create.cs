﻿using System;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using NetTopologySuite.Geometries;

namespace CirtasX.DataModels.Migrations
{
    public partial class Create : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Accidents",
                columns: table => new
                {
                    AccidentID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    AccidentRef = table.Column<string>(nullable: true),
                    BatchID = table.Column<string>(nullable: true),
                    RecordTypeID = table.Column<int>(nullable: false),
                    PoliceForceID = table.Column<int>(nullable: true),
                    YearOfRecord = table.Column<string>(nullable: true),
                    MonthOfRecord = table.Column<string>(nullable: true),
                    NoOfVehicles = table.Column<int>(nullable: false),
                    NoOfCasualties = table.Column<int>(nullable: false),
                    AccidentDateTime = table.Column<DateTime>(nullable: true),
                    LocalAuthorityID = table.Column<int>(nullable: false),
                    Easting = table.Column<decimal>(type: "decimal(30, 10)", nullable: true),
                    Northing = table.Column<decimal>(type: "decimal(30, 10)", nullable: true),
                    RoadTypeID = table.Column<int>(nullable: false),
                    FirstRoadClassID = table.Column<int>(nullable: false),
                    FirstRoadNo = table.Column<int>(nullable: true),
                    SecondRoadClassID = table.Column<int>(nullable: true),
                    SecondRoadNo = table.Column<int>(nullable: true),
                    SpeedLimit = table.Column<int>(nullable: true),
                    JunctionDetailID = table.Column<int>(nullable: false),
                    JunctionControlID = table.Column<int>(nullable: true),
                    PedCrossHumanControlID = table.Column<int>(nullable: false),
                    PedCrossPhysicalFacilityID = table.Column<int>(nullable: false),
                    LightConditionID = table.Column<int>(nullable: false),
                    WeatherID = table.Column<int>(nullable: false),
                    RoadSurfaceConditionID = table.Column<int>(nullable: false),
                    SpecialConditionID = table.Column<int>(nullable: false),
                    CarriagewayHazardID = table.Column<int>(nullable: false),
                    PoliceOfficerInAttendanceID = table.Column<int>(nullable: false),
                    DFTSpecialProjects = table.Column<string>(nullable: true),
                    GeneralDescription = table.Column<string>(nullable: true),
                    LocationDescription = table.Column<string>(nullable: true),
                    IsImported = table.Column<bool>(nullable: false),
                    CreatedOnDateTime = table.Column<DateTime>(nullable: false),
                    CreatedByUser = table.Column<string>(nullable: true),
                    AccidentSeverityID = table.Column<int>(nullable: false),
                    HasErrors = table.Column<bool>(nullable: false),
                    Geometry = table.Column<Geometry>(type: "geometry", nullable: true),
                    LocationNorthingPrefix = table.Column<string>(nullable: true),
                    STATSVersion = table.Column<decimal>(type: "decimal(30, 10)", nullable: false),
                    CollisionSeverityID = table.Column<int>(nullable: true),
                    LocalField1 = table.Column<string>(nullable: true),
                    LocalField2 = table.Column<string>(nullable: true),
                    LocalField3 = table.Column<string>(nullable: true),
                    LocalField4 = table.Column<string>(nullable: true),
                    LocalField5 = table.Column<string>(nullable: true),
                    LocalField6 = table.Column<string>(nullable: true),
                    LocalField7 = table.Column<string>(nullable: true),
                    LocalField8 = table.Column<string>(nullable: true),
                    LocalField9 = table.Column<string>(nullable: true),
                    LocalField10 = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Accidents", x => x.AccidentID);
                });

            migrationBuilder.CreateTable(
                name: "ContributoryFactors",
                columns: table => new
                {
                    ContributoryFactorID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    AccidentID = table.Column<int>(nullable: false),
                    BatchID = table.Column<string>(nullable: true),
                    FactorNo = table.Column<int>(nullable: false),
                    FactorID = table.Column<int>(nullable: true),
                    RelatedParty = table.Column<string>(nullable: true),
                    Confidence = table.Column<string>(nullable: true),
                    VehicleCasualtyRefNo = table.Column<int>(nullable: true),
                    IsImported = table.Column<bool>(nullable: false),
                    CreatedOnDateTime = table.Column<DateTime>(nullable: false),
                    CreatedByUser = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ContributoryFactors", x => x.ContributoryFactorID);
                    table.ForeignKey(
                        name: "FK_ContributoryFactors_Accidents_AccidentID",
                        column: x => x.AccidentID,
                        principalTable: "Accidents",
                        principalColumn: "AccidentID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Vehicles",
                columns: table => new
                {
                    VehicleID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    AccidentID = table.Column<int>(nullable: false),
                    BatchID = table.Column<string>(nullable: true),
                    VehicleRefNo = table.Column<int>(nullable: false),
                    RecordTypeID = table.Column<int>(nullable: false),
                    PoliceForceID = table.Column<int>(nullable: false),
                    YearOfRecord = table.Column<string>(nullable: true),
                    MonthOfRecord = table.Column<string>(nullable: true),
                    TypeOfVehicleID = table.Column<int>(nullable: false),
                    TowArticulationID = table.Column<int>(nullable: false),
                    ManoeuvreID = table.Column<int>(nullable: false),
                    FromVehicleDirectionID = table.Column<int>(nullable: false),
                    ToVehicleDirectionID = table.Column<int>(nullable: false),
                    VehicleLocationID = table.Column<int>(nullable: false),
                    JunctionLocationID = table.Column<int>(nullable: false),
                    SkiddingOverturningID = table.Column<int>(nullable: false),
                    HitObjectInCarriagewayID = table.Column<int>(nullable: false),
                    VehicleLeavingCarriagewayID = table.Column<int>(nullable: false),
                    FirstObjectHitOffCarriagewayID = table.Column<int>(nullable: false),
                    FirstPointOfImpactID = table.Column<int>(nullable: false),
                    FirstContactVehicleID = table.Column<int>(nullable: true),
                    SexOfDriverID = table.Column<int>(nullable: false),
                    AgeOfDriver = table.Column<int>(nullable: true),
                    BreathTestID = table.Column<int>(nullable: false),
                    HitAndRunID = table.Column<int>(nullable: false),
                    DFTSpecialProjects = table.Column<string>(nullable: true),
                    VRM = table.Column<string>(nullable: true),
                    DriverHomeOutPostCode = table.Column<string>(nullable: true),
                    DriverHomeInPostCode = table.Column<string>(nullable: true),
                    ForeignRegisteredVehicleID = table.Column<int>(nullable: false),
                    JourneyPurposeID = table.Column<int>(nullable: false),
                    IsImported = table.Column<bool>(nullable: false),
                    CreatedOnDateTime = table.Column<DateTime>(nullable: false),
                    CreatedByUser = table.Column<string>(nullable: true),
                    WasVehicleLeftHandDriveID = table.Column<int>(nullable: false),
                    OtherVehicle = table.Column<string>(nullable: true),
                    LicenseAppropriateID = table.Column<int>(nullable: true),
                    MakeOfVehicle = table.Column<string>(nullable: true),
                    ModelDetails = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Vehicles", x => x.VehicleID);
                    table.ForeignKey(
                        name: "FK_Vehicles_Accidents_AccidentID",
                        column: x => x.AccidentID,
                        principalTable: "Accidents",
                        principalColumn: "AccidentID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Casualties",
                columns: table => new
                {
                    CasualtyID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    AccidentID = table.Column<int>(nullable: false),
                    BatchID = table.Column<string>(nullable: true),
                    VehicleID = table.Column<int>(nullable: true),
                    CasualtyRefNo = table.Column<int>(nullable: false),
                    RecordTypeID = table.Column<int>(nullable: false),
                    PoliceForceID = table.Column<int>(nullable: false),
                    YearOfRecord = table.Column<string>(nullable: true),
                    MonthOfRecord = table.Column<string>(nullable: true),
                    CasualtyClassID = table.Column<int>(nullable: false),
                    SexOfCasualtyID = table.Column<int>(nullable: false),
                    AgeOfCasualty = table.Column<int>(nullable: true),
                    CasualtySeverityID = table.Column<int>(nullable: false),
                    PedestrianLocationID = table.Column<int>(nullable: true),
                    PedestrianMovementID = table.Column<int>(nullable: true),
                    PedestrianDirectionID = table.Column<int>(nullable: true),
                    SchoolPupilID = table.Column<int>(nullable: false),
                    CarPassengerID = table.Column<int>(nullable: false),
                    BusCoachPassengerID = table.Column<int>(nullable: false),
                    DFTSpecialProjects = table.Column<string>(nullable: true),
                    HomeOutPostCode = table.Column<string>(nullable: true),
                    HomeInPostCode = table.Column<string>(nullable: true),
                    PedestrianInjuredOnRoadWorksID = table.Column<int>(nullable: true),
                    IsImported = table.Column<bool>(nullable: false),
                    CreatedOnDateTime = table.Column<DateTime>(nullable: false),
                    CreatedByUser = table.Column<string>(nullable: true),
                    SeatBeltID = table.Column<int>(nullable: false),
                    CycleHelmetWornID = table.Column<int>(nullable: false),
                    CasCollisionSeverityID = table.Column<int>(nullable: true),
                    AdmittedToHospitalID = table.Column<int>(nullable: true),
                    MostSevereInjuryID = table.Column<int>(nullable: true),
                    OtherInjury = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Casualties", x => x.CasualtyID);
                    table.ForeignKey(
                        name: "FK_Casualties_Accidents_AccidentID",
                        column: x => x.AccidentID,
                        principalTable: "Accidents",
                        principalColumn: "AccidentID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Casualties_Vehicles_VehicleID",
                        column: x => x.VehicleID,
                        principalTable: "Vehicles",
                        principalColumn: "VehicleID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Casualties_AccidentID",
                table: "Casualties",
                column: "AccidentID");

            migrationBuilder.CreateIndex(
                name: "IX_Casualties_VehicleID",
                table: "Casualties",
                column: "VehicleID");

            migrationBuilder.CreateIndex(
                name: "IX_ContributoryFactors_AccidentID",
                table: "ContributoryFactors",
                column: "AccidentID");

            migrationBuilder.CreateIndex(
                name: "IX_Vehicles_AccidentID",
                table: "Vehicles",
                column: "AccidentID");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Casualties");

            migrationBuilder.DropTable(
                name: "ContributoryFactors");

            migrationBuilder.DropTable(
                name: "Vehicles");

            migrationBuilder.DropTable(
                name: "Accidents");
        }
    }
}
