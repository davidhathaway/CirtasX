﻿using System;

namespace CirtasX.DataModels
{
    public class ContributoryFactor
    {
        public int ContributoryFactorID { get; set; }
        public int AccidentID { get; set; }
        public string BatchID { get; set; }
        public int FactorNo { get; set; }
        public int? FactorID { get; set; }
        public string RelatedParty { get; set; }
        public string Confidence { get; set; }
        public int? VehicleCasualtyRefNo { get; set; }
        public bool IsImported { get; set; }
        public DateTime CreatedOnDateTime { get; set; }
        public string CreatedByUser { get; set; }
        public Accident Accident { get; set; }
    }
}