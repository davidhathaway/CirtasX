﻿using GeoAPI.Geometries;
using NetTopologySuite.Geometries;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace CirtasX.DataModels
{
    public class Accident
    {
        public Accident()
        {
            this.Casualties = new HashSet<Casualty>();
            this.ContributoryFactors = new HashSet<ContributoryFactor>();
            this.Vehicles = new HashSet<Vehicle>();
        }

        public int AccidentID { get; set; }
        public string AccidentRef { get; set; }
        public string BatchID { get; set; }
        public int RecordTypeID { get; set; }
        public int? PoliceForceID { get; set; }
        public string YearOfRecord { get; set; }
        public string MonthOfRecord { get; set; }
        public int NoOfVehicles { get; set; }
        public int NoOfCasualties { get; set; }

        public DateTime? AccidentDateTime { get; set; }
        public int LocalAuthorityID { get; set; }

        [Column(TypeName = "decimal(30, 10)")]
        public decimal? Easting { get; set; }

        [Column(TypeName = "decimal(30, 10)")]
        public decimal? Northing { get; set; }
        public int RoadTypeID { get; set; }
        public int FirstRoadClassID { get; set; }
        public int? FirstRoadNo { get; set; }
        public int? SecondRoadClassID { get; set; }
        public int? SecondRoadNo { get; set; }
        public int? SpeedLimit { get; set; }
        public int JunctionDetailID { get; set; }
        public int? JunctionControlID { get; set; }
        public int PedCrossHumanControlID { get; set; }
        public int PedCrossPhysicalFacilityID { get; set; }
        public int LightConditionID { get; set; }
        public int WeatherID { get; set; }
        public int RoadSurfaceConditionID { get; set; }
        public int SpecialConditionID { get; set; }
        public int CarriagewayHazardID { get; set; }
        public int PoliceOfficerInAttendanceID { get; set; }
        public string DFTSpecialProjects { get; set; }
        public string GeneralDescription { get; set; }
        public string LocationDescription { get; set; }
        public bool IsImported { get; set; }
        public DateTime CreatedOnDateTime { get; set; }
        public string CreatedByUser { get; set; }
        public int AccidentSeverityID { get; set; }
        public bool HasErrors { get; set; }

        [Column(TypeName = "geometry")]
        public Geometry Geometry { get; set; }


        public string LocationNorthingPrefix { get; set; }

        [Column(TypeName = "decimal(30, 10)")]
        public decimal STATSVersion { get; set; }

        public int? CollisionSeverityID { get; set; }
        public string LocalField1 { get; set; }
        public string LocalField2 { get; set; }
        public string LocalField3 { get; set; }
        public string LocalField4 { get; set; }
        public string LocalField5 { get; set; }
        public string LocalField6 { get; set; }
        public string LocalField7 { get; set; }
        public string LocalField8 { get; set; }
        public string LocalField9 { get; set; }
        public string LocalField10 { get; set; }
        public ICollection<Casualty> Casualties { get; private set; }
        public ICollection<ContributoryFactor> ContributoryFactors { get; private set; }
        public ICollection<Vehicle> Vehicles { get; private set; }
    }
}
