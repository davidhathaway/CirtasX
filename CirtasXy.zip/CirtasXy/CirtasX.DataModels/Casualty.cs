﻿using System;

namespace CirtasX.DataModels
{
    public class Casualty
    {
        public int CasualtyID { get; set; }
        public int AccidentID { get; set; }
        public string BatchID { get; set; }
        public int? VehicleID { get; set; }
        public int CasualtyRefNo { get; set; }
        public int RecordTypeID { get; set; }
        public int PoliceForceID { get; set; }
        public string YearOfRecord { get; set; }
        public string MonthOfRecord { get; set; }
        public int CasualtyClassID { get; set; }
        public int SexOfCasualtyID { get; set; }
        public int? AgeOfCasualty { get; set; }
        public int CasualtySeverityID { get; set; }
        public int? PedestrianLocationID { get; set; }
        public int? PedestrianMovementID { get; set; }
        public int? PedestrianDirectionID { get; set; }
        public int SchoolPupilID { get; set; }
        public int CarPassengerID { get; set; }
        public int BusCoachPassengerID { get; set; }
        public string DFTSpecialProjects { get; set; }
        public string HomeOutPostCode { get; set; }
        public string HomeInPostCode { get; set; }
        public int? PedestrianInjuredOnRoadWorksID { get; set; }
        public bool IsImported { get; set; }
        public DateTime CreatedOnDateTime { get; set; }
        public string CreatedByUser { get; set; }
        public int SeatBeltID { get; set; }
        public int CycleHelmetWornID { get; set; }
        public int? CasCollisionSeverityID { get; set; }
        public int? AdmittedToHospitalID { get; set; }
        public int? MostSevereInjuryID { get; set; }
        public string OtherInjury { get; set; }

        public virtual Accident Accident { get; set; }
    }
}