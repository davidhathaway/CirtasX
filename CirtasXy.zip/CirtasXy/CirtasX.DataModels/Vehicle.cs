﻿using System;
using System.Collections.Generic;

namespace CirtasX.DataModels
{
        public class Vehicle
        {
            public Vehicle()
            {
                this.Casualties = new HashSet<Casualty>();
            }

            public int VehicleID { get; set; }
            public int AccidentID { get; set; }
            public string BatchID { get; set; }
            public int VehicleRefNo { get; set; }
            public int RecordTypeID { get; set; }
            public int PoliceForceID { get; set; }
            public string YearOfRecord { get; set; }
            public string MonthOfRecord { get; set; }
            public int TypeOfVehicleID { get; set; }
            public int TowArticulationID { get; set; }
            public int ManoeuvreID { get; set; }
            public int FromVehicleDirectionID { get; set; }
            public int ToVehicleDirectionID { get; set; }
            public int VehicleLocationID { get; set; }
            public int JunctionLocationID { get; set; }
            public int SkiddingOverturningID { get; set; }
            public int HitObjectInCarriagewayID { get; set; }
            public int VehicleLeavingCarriagewayID { get; set; }
            public int FirstObjectHitOffCarriagewayID { get; set; }
            public int FirstPointOfImpactID { get; set; }
            public int? FirstContactVehicleID { get; set; }
            public int SexOfDriverID { get; set; }
            public int? AgeOfDriver { get; set; }
            public int BreathTestID { get; set; }
            public int HitAndRunID { get; set; }
            public string DFTSpecialProjects { get; set; }
            public string VRM { get; set; }
            public string DriverHomeOutPostCode { get; set; }
            public string DriverHomeInPostCode { get; set; }
            public int ForeignRegisteredVehicleID { get; set; }
            public int JourneyPurposeID { get; set; }
            public bool IsImported { get; set; }
            public DateTime CreatedOnDateTime { get; set; }
            public string CreatedByUser { get; set; }
            public int WasVehicleLeftHandDriveID { get; set; }
            public string OtherVehicle { get; set; }
            public int? LicenseAppropriateID { get; set; }
            public string MakeOfVehicle { get; set; }
            public string ModelDetails { get; set; }

            public Accident Accident { get; set; }

            public ICollection<Casualty> Casualties { get; set; }
        }
    
}