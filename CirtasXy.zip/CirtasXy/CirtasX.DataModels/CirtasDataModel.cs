﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace CirtasX.DataModels
{
    public class CirtasDataModel : DbContext
    {
        public DbSet<Accident> Accidents { get; set; }

        public DbSet<Casualty> Casualties { get; set; }

        public DbSet<Vehicle> Vehicles { get; set; }

        public DbSet<ContributoryFactor> ContributoryFactors { get; set; }

        public CirtasDataModel(DbContextOptions<CirtasDataModel> options)
          : base(options)
        {

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<Accident>()
                .HasKey(x => x.AccidentID);

            modelBuilder.Entity<Accident>()
                .HasMany(x => x.Vehicles)
                .WithOne(x=>x.Accident)
                .HasForeignKey(x=>x.AccidentID);

            modelBuilder.Entity<Accident>()
               .HasMany(x => x.Casualties)
               .WithOne(x => x.Accident)
               .HasForeignKey(x => x.AccidentID);


            modelBuilder.Entity<Accident>()
                .HasMany(x => x.ContributoryFactors)
                .WithOne(x => x.Accident)
                .HasForeignKey(x => x.AccidentID);

            modelBuilder.Entity<Vehicle>()
                .HasKey(x => x.VehicleID);

            modelBuilder.Entity<Vehicle>()
                .HasMany(x => x.Casualties)
                .WithOne()
                .HasForeignKey(x => x.VehicleID);

            modelBuilder.Entity<Casualty>()
                .HasKey(x => x.CasualtyID);

        }
    }
}
